import React from 'react';
import axios from 'axios';

export default function TaskItem({ task }) {
  async function toggleComplete() {
    await axios.put(`/api/tasks/${task._id}`, { completed: !task.completed });
    window.dispatchEvent(new Event('tasks:refresh'));
  }

  async function remove() {
    await axios.delete(`/api/tasks/${task._id}`);
    window.dispatchEvent(new Event('tasks:refresh'));
  }

  return (
    <div className="card">
      <div>
        <div className={task.completed ? 'strike' : ''}><strong>{task.title}</strong></div>
        {task.description && <div className={task.completed ? 'strike' : ''}>{task.description}</div>}
        <div className="row meta">
          <span className="tag">Priority: {task.priority}</span>
          {task.dueDate && <span>Due: {new Date(task.dueDate).toLocaleString()}</span>}
          {task.completed && <span className="tag">Done</span>}
        </div>
      </div>
      <div className="row">
        <button onClick={toggleComplete}>{task.completed ? 'Undo' : 'Complete'}</button>
        <button onClick={remove}>Delete</button>
      </div>
    </div>
  );
}
