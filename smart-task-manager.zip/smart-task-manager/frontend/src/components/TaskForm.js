import React, { useState } from 'react';
import axios from 'axios';

export default function TaskForm() {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState('Medium');
  const [dueDate, setDueDate] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    await axios.post('/api/tasks', { title, description, priority, dueDate });
    setTitle(''); setDescription(''); setPriority('Medium'); setDueDate('');
    // refresh list
    window.dispatchEvent(new Event('tasks:refresh'));
  }

  return (
    <form onSubmit={handleSubmit}>
      <input value={title} onChange={(e)=>setTitle(e.target.value)} placeholder="Task title" required />
      <input value={description} onChange={(e)=>setDescription(e.target.value)} placeholder="Description" />
      <select value={priority} onChange={(e)=>setPriority(e.target.value)}>
        <option>Low</option>
        <option>Medium</option>
        <option>High</option>
      </select>
      <input type="datetime-local" value={dueDate} onChange={(e)=>setDueDate(e.target.value)} />
      <button type="submit">Add</button>
    </form>
  );
}
