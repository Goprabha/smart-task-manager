import React, { useEffect, useState } from 'react';
import axios from 'axios';
import TaskItem from './TaskItem';

export default function TaskList() {
  const [tasks, setTasks] = useState([]);
  const [filter, setFilter] = useState('all');

  async function load() {
    const params = {};
    if (filter === 'done') params.completed = true;
    if (filter === 'todo') params.completed = false;
    const res = await axios.get('/api/tasks', { params });
    setTasks(res.data);
  }

  useEffect(() => { load(); }, [filter]);
  useEffect(() => {
    function onRefresh(){ load(); }
    window.addEventListener('tasks:refresh', onRefresh);
    return () => window.removeEventListener('tasks:refresh', onRefresh);
  }, []);

  return (
    <div>
      <div className="row" style={{ margin: '8px 0 12px' }}>
        <label>Filter:</label>
        <select value={filter} onChange={(e)=>setFilter(e.target.value)}>
          <option value="all">All</option>
          <option value="todo">To-do</option>
          <option value="done">Completed</option>
        </select>
      </div>
      <div className="list">
        {tasks.map(t => <TaskItem key={t._id} task={t} />)}
        {tasks.length === 0 && <div className="meta">No tasks found.</div>}
      </div>
    </div>
  );
}
