import React from 'react';
import TaskForm from './components/TaskForm';
import TaskList from './components/TaskList';

export default function App() {
  return (
    <div className="container">
      <header>
        <h1>Smart Task Manager</h1>
        <p className="subtitle">Organize tasks, set priorities, and stay on track.</p>
      </header>
      <TaskForm />
      <TaskList />
    </div>
  );
}
