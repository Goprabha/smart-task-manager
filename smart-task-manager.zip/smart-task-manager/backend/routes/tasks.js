const express = require('express');
const router = express.Router();
const Task = require('../models/Task');

// Get all tasks (optionally filter by completed, priority)
router.get('/', async (req, res) => {
  try {
    const query = {};
    if (req.query.completed === 'true' || req.query.completed === 'false') {
      query.completed = req.query.completed === 'true';
    }
    if (req.query.priority) {
      query.priority = req.query.priority;
    }
    const tasks = await Task.find(query).sort({ createdAt: -1 });
    res.json(tasks);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get due-soon tasks (next 24 hours)
router.get('/due/soon', async (_req, res) => {
  try {
    const now = new Date();
    const in24 = new Date(Date.now() + 24*60*60*1000);
    const tasks = await Task.find({
      completed: false,
      dueDate: { $gte: now, $lte: in24 }
    }).sort({ dueDate: 1 });
    res.json(tasks);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get task by ID
router.get('/:id', async (req, res) => {
  try {
    const task = await Task.findById(req.params.id);
    if (!task) return res.status(404).json({ message: 'Task not found' });
    res.json(task);
  } catch (err) {
    res.status(404).json({ message: 'Task not found' });
  }
});

// Create task
router.post('/', async (req, res) => {
  try {
    const { title, description, priority, dueDate } = req.body;
    const task = new Task({ title, description, priority, dueDate });
    const newTask = await task.save();
    res.status(201).json(newTask);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Update task
router.put('/:id', async (req, res) => {
  try {
    const updatedTask = await Task.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!updatedTask) return res.status(404).json({ message: 'Task not found' });
    res.json(updatedTask);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Delete task
router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Task.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ message: 'Task not found' });
    res.json({ message: 'Task deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
