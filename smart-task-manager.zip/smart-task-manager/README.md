# Smart Task Manager

A full-stack task manager built with **React** (frontend), **Node.js + Express** (backend), and **MongoDB** (database).
It lets users create, update, delete tasks, set priorities, and add due dates. Includes a simple "due soon" API.

## ✨ Features
- Create, read, update, delete tasks
- Priorities: Low / Medium / High
- Optional due date & "due soon" endpoint
- Filter by completion state
- Clean, responsive UI

## 🧰 Tech Stack
- **Frontend:** React 18, Axios
- **Backend:** Node.js, Express
- **Database:** MongoDB (Mongoose)
- **Dev Tools:** Nodemon, Git

## 🚀 Local Setup

### 1) Backend
```bash
cd backend
npm install
cp .env.example .env   # then edit .env and set MONGO_URI
npm run dev            # starts on http://localhost:5000
```

### 2) Frontend
```bash
cd ../frontend
npm install
npm start              # opens http://localhost:3000
```

The frontend proxy is set to `http://localhost:5000`, so Axios calls like `/api/tasks` will work locally.

## 📡 API Endpoints
- `GET /api/tasks` – list tasks (query: `completed=true|false`, `priority=Low|Medium|High`)
- `GET /api/tasks/due/soon` – tasks due in the next 24 hours
- `GET /api/tasks/:id` – get single task
- `POST /api/tasks` – create task
  ```json
  {
    "title": "Finish report",
    "description": "Summarize Q3 metrics",
    "priority": "High",
    "dueDate": "2025-08-25T15:30:00.000Z"
  }
  ```
- `PUT /api/tasks/:id` – update task (any fields)
- `DELETE /api/tasks/:id` – delete task

## 🔐 Environment Variables (backend/.env)
```env
MONGO_URI=mongodb+srv://<user>:<password>@<cluster>/<db>?retryWrites=true&w=majority
PORT=5000
```

## 📦 Production Notes
- Deploy backend to Render/Railway/Heroku and frontend to Netlify/Vercel.
- In production, set the frontend to call your deployed API base URL instead of relying on the proxy.

## 📝 License
MIT
